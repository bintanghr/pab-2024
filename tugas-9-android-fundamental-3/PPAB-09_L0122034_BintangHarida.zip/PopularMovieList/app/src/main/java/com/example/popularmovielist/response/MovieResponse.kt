package com.example.popularmovielist.response

import com.example.popularmovielist.ui.Movie

data class MovieResponse(
    val results: List<Movie>
)
