package com.example.coffeeordering.ui.coffee

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.coffeeordering.R

class ListMenuAdapter(private val context: Context,
                      private val listMenu: ArrayList<Menu>) :
    RecyclerView.Adapter<ListMenuAdapter.ListViewHolder>(),
    View.OnClickListener {
    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
        val tvPrice: TextView = itemView.findViewById(R.id.tv_item_price)
        val tvName: TextView = itemView.findViewById(R.id.tv_item_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_row_coffee, parent, false)
        return ListViewHolder(view)
    }

    override fun getItemCount(): Int = listMenu.size

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val (name, price, desc, img) = listMenu[position]
        val priceText = "Rp $price"
        holder.imgPhoto.setImageResource(img)
        holder.tvPrice.text = priceText
        holder.tvName.text = name
//        holder.itemView.setOnClickListener{
//            val detailsIntent = Intent(context, DetailsActivity::class.java)
//            detailsIntent.putExtra(DetailsActivity.EXTRA_NAME, name)
//            detailsIntent.putExtra(DetailsActivity.EXTRA_PRICE, price)
//            detailsIntent.putExtra(DetailsActivity.EXTRA_DESC, desc)
//            detailsIntent.putExtra(DetailsActivity.EXTRA_IMG, img)
//            context.startActivity(detailsIntent)
//        }
    }

    override fun onClick(v: View?) {
        TODO("Not yet implemented")
    }
}